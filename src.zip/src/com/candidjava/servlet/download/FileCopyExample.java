package com.candidjava.servlet.download;
import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;

@WebServlet("/FileCopyExample")
public class FileCopyExample extends HttpServlet {
   private static final long serialVersionUID = 1L;
   
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      response.setContentType("text/html");
	      String filename = request.getParameter("filename");
	      String filepath = "D:/uploads/";
	      //absolute path for source file
	        String source = filepath+filename;
	        //directory where file will be copied
	        String target ="D:/verified/";
	      
	        //name of source file
	        File sourceFile = new File(source);
	        String name = sourceFile.getName();
	      
	        File targetFile = new File(target+name);
	        System.out.println("Copying file : " + sourceFile.getName() +" from Java Program");
	      
	        //copy file from one location to other
	        FileUtils.copyFile(sourceFile, targetFile);
	      
	        System.out.println("copying of file from Java program is completed");
	        request.getRequestDispatcher("JSP/Download.jsp").forward(request, response);
	        
   }
  
}
